// script.js
function greetUser() {
        // This will prompt the user
        let username = prompt("What is your name?");
        document.getElementById("output").innerHTML = "Hello, " + username + "! Welcome to our web page.";
 };

// Call the function when the page loads
greetUser();

let localTime = new Date();
document.getElementById("time").innerHTML =
  "The local time is: " + localTime.toLocaleString();